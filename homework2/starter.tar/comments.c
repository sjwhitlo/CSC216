#include <stdio.h>
#include <stdlib.h>

/** Total count of characters. */
int totalChars = 0;

/** Total count of characters that are part of a comment. */
int commentChars = 0;

/** Total number of comments in the input. */
int commentCount = 0;

void processComment()
{
  // ...
}
